<?php
/**
 * Script to build the installable zip file for the extension
 *
 * We create a tmp folder and copy the files into it and zip it up.
 */
$adminPath = dirname(__FILE__);
$basePath = dirname(dirname(dirname(dirname(__FILE__))));
$sitePath = $basePath . '/components/com_joomprosubs/';
$tempPath = $basePath . '/tmp/' . date('YmdHis');
define('JPATH_BASE',$basePath);
define('_JEXEC', 1);

require_once $basePath . '/includes/defines.php';
require_once $basePath . '/libraries/import.php';
require_once $basePath . '/libraries/joomla/filesystem/folder.php';
require_once $basePath . '/libraries/joomla/filesystem/file.php';


$result = JFolder::create($tempPath);
// $result = JFolder::create($tempPath . '/admin');
// $result = JFolder::create($tempPath . '/site');
$result = JFolder::copy($adminPath, $tempPath . '/admin');
$result = JFolder::copy($sitePath, $tempPath . '/site');
$result = JFile::copy($tempPath . '/admin/joomprosubs.xml', $tempPath . '/joomprosubs.xml');
$result = JFile::delete($tempPath . '/admin/joomprosubs.xml');







