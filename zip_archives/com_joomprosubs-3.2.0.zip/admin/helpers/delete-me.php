<?php
// This is a file to demonstrate how to delete files during an update
// It should be deleted during the update from 1.6.1 to 1.6.2
?>