DROP TABLE IF EXISTS `#__joompro_subscriptions`;
DROP TABLE IF EXISTS `#__joompro_sub_mapping`;